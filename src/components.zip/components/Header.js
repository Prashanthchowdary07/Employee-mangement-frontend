import React from "react";
const Header=()=>{
    return(
        <div>
            <h1>Employee management application</h1>
        </div>
    )
}
export default Header